# CraftFlow · page de présentation

Page statique (HTML, CSS, un peu de JavaScript) qui présente le projet CraftFlow : l'introduction avec l'image de couverture, le projet, les fonctionnalités, les technologies et le développeur. Aucun outil de build : les fichiers se publient tels quels.

## 1. Renseigner l'adresse de l'application

Les deux boutons « Ouvrir l'application » (introduction et bas de page) pointent pour l'instant vers une adresse volontairement invalide : `https://application-non-deployee.invalid/`. Une fois l'application déployée, remplacez-la partout avec une seule commande (en mettant votre adresse) :

```bash
sed -i 's#https://application-non-deployee.invalid/#https://VOTRE-ADRESSE/#g' index.html
```

Vérifiez ensuite qu'il n'en reste plus :

```bash
grep -n "non-deployee" index.html
```

## 2. Publier sur GitHub Pages

Le dépôt doit être **public** (les dépôts privés exigent un abonnement payant pour GitHub Pages).

1. Copiez le contenu de ce dossier dans le dossier `docs/` du dépôt (`index.html`, `style.css`, `script.js`, `favicon.svg`, `assets/`, `.nojekyll`).
2. Faites un commit, puis un push.
3. Sur GitHub : **Settings**, **Pages**, **Build and deployment**, source **Deploy from a branch**, branche **main**, dossier **/docs**, puis **Save**.
4. Après une à deux minutes, la page est disponible sur `https://<votre-compte>.github.io/<nom-du-depot>/`.

Autre possibilité : créer un dépôt séparé, y mettre ces fichiers à la racine, et choisir le dossier **/ (root)**.

## 3. Aperçu local

```bash
python3 -m http.server 8081
```

Puis ouvrir http://localhost:8081.

## Contenu

| Fichier | Rôle |
|---|---|
| `index.html` | La page : en-tête, introduction, quatre sections, appel à l'action, pied de page |
| `style.css` | Mise en page, thème clair et sombre, version mobile |
| `script.js` | Menu mobile et surlignage de la section affichée |
| `assets/cover.svg` | Image de couverture : une grille de créneaux horaires |
| `assets/img/` | Captures de l'application et schéma d'architecture |
| `assets/og-image.png` | Image d'aperçu quand le lien est partagé |

## Bon à savoir

- Les captures montrent des **données de démonstration** (comptes fictifs).
- Pour que l'aperçu du lien partagé fonctionne sur les réseaux sociaux, remplacez dans `index.html` la valeur de `og:image` par l'adresse complète de l'image une fois la page publiée.
